package com.example.a42567321.pruebaprog;

import android.content.Context;
import android.util.Log;
import android.view.MotionEvent;

import org.cocos2d.actions.interval.IntervalAction;
import org.cocos2d.actions.interval.MoveBy;
import org.cocos2d.actions.interval.MoveTo;
import org.cocos2d.actions.interval.RotateBy;
import org.cocos2d.actions.interval.ScaleBy;
import org.cocos2d.actions.interval.ScaleTo;
import org.cocos2d.actions.interval.Sequence;
import org.cocos2d.layers.Layer;
import org.cocos2d.nodes.Director;
import org.cocos2d.nodes.Scene;
import org.cocos2d.nodes.Sprite;
import org.cocos2d.opengl.CCGLSurfaceView;
import org.cocos2d.types.CCSize;

import java.util.Random;

/**
 * Created by 42567321 on 21/11/2017.
 */

public class Game {
    CCGLSurfaceView view;
    Context context;
    CCSize screen;

    public Game(CCGLSurfaceView view, Context context) {
        this.view = view;
        this.context = context;
    }

    public void start(){
        Director.sharedDirector().attachInView(view);
        screen = Director.sharedDirector().displaySize();
        Log.d("start", "Screen size: " + screen.getWidth() + " width and " + screen.getHeight() + " height");
        Director.sharedDirector().runWithScene(Scene());
    }

    private Scene Scene(){
        Scene scene = Scene.node();
        scene.addChild(new myLayer());

        return scene;
    }

    class myLayer extends Layer{
        Sprite red, blue;
        float currentX;
        int alreadyRotated;
        boolean redMoved;

        public myLayer() {
            this.setIsTouchEnabled(true);

            currentX = 0;
            alreadyRotated = 0;

            red = Sprite.sprite("red.jpg");
            red.setPosition(screen.getWidth()/2, screen.getHeight()*3/4);

            blue = Sprite.sprite("blue.jpg");
            blue.setPosition(screen.getWidth()/2, screen.getHeight()/4);

            Log.d("Red position", red.getPositionX() + ", " + red.getPositionY());
            Log.d("Blue position", blue.getPositionX() + ", " + blue.getPositionY());

            super.addChild(red).addChild(blue);
        }

        @Override
        public boolean ccTouchesBegan(MotionEvent event) {
            int random = new Random().nextInt(2);

            if (random == 0){
                red.runAction(MoveTo.action(1f, screen.getWidth() - red.getWidth()/2,
                        screen.getHeight() - red.getHeight()/2));
                redMoved = true;
            } else {
                blue.runAction(MoveTo.action(1f, screen.getWidth() - red.getWidth()/2,
                        screen.getHeight() - red.getHeight()/2));
                redMoved = false;
            }

            return super.ccTouchesBegan(event);
        }

        @Override
        public boolean ccTouchesMoved(MotionEvent event) {
            if (currentX != 0){
                if (currentX < event.getX()) {
                    if (redMoved){
                        if (blue.getRotation() < 345)
                            blue.runAction(RotateBy.action(0.2f, 15));
                    } else {
                        if (red.getRotation() < 345)
                            red.runAction(RotateBy.action(0.2f, 15));
                    }
                } else if (currentX > event.getX()) {
                    if (redMoved){
                        if (blue.getRotation() > -345)
                            blue.runAction(RotateBy.action(0.2f, -15));
                    } else {
                        if (blue.getRotation() > -345)
                            red.runAction(RotateBy.action(0.2f, -15));
                    }
                }
            }

            if (redMoved)
                Log.d("Current rotation", String.valueOf(blue.getRotation()));
            else
                Log.d("Current rotation", String.valueOf(red.getRotation()));

            currentX = event.getX();
            return super.ccTouchesMoved(event);
        }

        @Override
        public boolean ccTouchesEnded(MotionEvent event) {
            run(red);
            run(blue);
            return super.ccTouchesEnded(event);
        }

        private void run(Sprite sprite){
            IntervalAction sequence = Sequence.actions(ScaleTo.action(0.5f, 1.5f), ScaleTo.action(0.5f, 1f),
                    ScaleTo.action(0.5f, 1.5f), ScaleTo.action(0.5f, 1f),
                    ScaleTo.action(0.5f, 1.5f), ScaleTo.action(0.5f, 1f));
            sprite.runAction(sequence);
        }
    }
}
